-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 20, 2020 at 03:58 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kereta`
--

-- --------------------------------------------------------

--
-- Table structure for table `kereta_data`
--

CREATE TABLE `kereta_data` (
  `kd_id` bigint(11) NOT NULL,
  `kd_nama` varchar(255) NOT NULL,
  `kd_asal` varchar(255) NOT NULL,
  `kd_tujuan` varchar(255) NOT NULL,
  `kd_price` int(11) NOT NULL,
  `kd_stock` int(11) NOT NULL,
  `kd_created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kereta_data`
--

INSERT INTO `kereta_data` (`kd_id`, `kd_nama`, `kd_asal`, `kd_tujuan`, `kd_price`, `kd_stock`, `kd_created_at`) VALUES
(1, 'Argowisata', 'Surakarta', 'Semarang', 15000, 45, '2020-05-20 13:20:45'),
(2, 'Pramek', 'Surakarta', 'Yogyakarta', 8000, 150, '2020-05-20 13:33:03');

-- --------------------------------------------------------

--
-- Table structure for table `transaction_data`
--

CREATE TABLE `transaction_data` (
  `td_id` bigint(11) NOT NULL,
  `td_user` bigint(11) NOT NULL,
  `td_kereta` bigint(11) NOT NULL,
  `td_amount` int(5) NOT NULL,
  `td_voucher` bigint(11) NOT NULL,
  `td_created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaction_data`
--

INSERT INTO `transaction_data` (`td_id`, `td_user`, `td_kereta`, `td_amount`, `td_voucher`, `td_created_at`) VALUES
(10, 16, 2, 2, 1, '2020-05-20 13:40:36');

-- --------------------------------------------------------

--
-- Table structure for table `user_data`
--

CREATE TABLE `user_data` (
  `ud_id` bigint(11) NOT NULL,
  `ud_email` varchar(255) NOT NULL,
  `ud_password` varchar(255) NOT NULL,
  `ud_role` int(1) NOT NULL,
  `ud_saldo` int(10) NOT NULL,
  `ud_created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_data`
--

INSERT INTO `user_data` (`ud_id`, `ud_email`, `ud_password`, `ud_role`, `ud_saldo`, `ud_created_at`) VALUES
(12, 'alexandromeo@makinrajin.com', 'pass', 1, 0, '2020-04-28 13:17:54'),
(13, 'alexandromeo123@gmail.com', 'pass', 2, 0, '2020-04-28 13:18:22'),
(14, 'alex@gmail.com', 'pass', 1, 0, '2020-04-28 14:06:48'),
(15, 'a', 'a', 1, 0, '2020-04-29 07:16:28'),
(16, 'b', 'b', 2, 74000, '2020-05-20 13:40:36'),
(17, 'c', 'c', 2, 25000, '2020-05-03 01:24:21');

-- --------------------------------------------------------

--
-- Table structure for table `voucher_data`
--

CREATE TABLE `voucher_data` (
  `vd_id` bigint(11) NOT NULL,
  `vd_name` varchar(255) NOT NULL,
  `vd_discount` int(3) NOT NULL,
  `vd_duration` int(5) NOT NULL,
  `vd_created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `voucher_data`
--

INSERT INTO `voucher_data` (`vd_id`, `vd_name`, `vd_discount`, `vd_duration`, `vd_created_at`) VALUES
(1, '', 0, 999999999, '2020-05-01 03:17:45'),
(2, 'COBASINI', 25, 10, '2020-04-30 06:19:26'),
(3, 'DIS10', 10, 5, '2020-05-01 03:17:18'),
(5, 'b', 10, 6, '2020-05-15 13:29:40');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kereta_data`
--
ALTER TABLE `kereta_data`
  ADD PRIMARY KEY (`kd_id`);

--
-- Indexes for table `transaction_data`
--
ALTER TABLE `transaction_data`
  ADD PRIMARY KEY (`td_id`),
  ADD KEY `td_voucher` (`td_voucher`),
  ADD KEY `td_user` (`td_user`),
  ADD KEY `transaction_data_ibfk_3` (`td_kereta`);

--
-- Indexes for table `user_data`
--
ALTER TABLE `user_data`
  ADD PRIMARY KEY (`ud_id`);

--
-- Indexes for table `voucher_data`
--
ALTER TABLE `voucher_data`
  ADD PRIMARY KEY (`vd_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `kereta_data`
--
ALTER TABLE `kereta_data`
  MODIFY `kd_id` bigint(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `transaction_data`
--
ALTER TABLE `transaction_data`
  MODIFY `td_id` bigint(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `user_data`
--
ALTER TABLE `user_data`
  MODIFY `ud_id` bigint(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `voucher_data`
--
ALTER TABLE `voucher_data`
  MODIFY `vd_id` bigint(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `transaction_data`
--
ALTER TABLE `transaction_data`
  ADD CONSTRAINT `transaction_data_ibfk_1` FOREIGN KEY (`td_voucher`) REFERENCES `voucher_data` (`vd_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `transaction_data_ibfk_2` FOREIGN KEY (`td_user`) REFERENCES `user_data` (`ud_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `transaction_data_ibfk_3` FOREIGN KEY (`td_kereta`) REFERENCES `kereta_data` (`kd_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
